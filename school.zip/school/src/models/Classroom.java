package models;


import java.util.concurrent.Semaphore;

public class Classroom {
    private static final int MAX_LECTURER = 1;

    private final Semaphore numOfLecturers = new Semaphore(MAX_LECTURER, true);

    private String title;
    private int capacity;
    private boolean inSession = false;
    private boolean isLecturer = false;
    private boolean isSeated = false;

    public  Classroom(){
    }

    public Classroom(String title, int capacity) {
        this.title = title;
        this.capacity = capacity;
    }

// invoke by student
    public void enter(String person) {
        if (person.equals("lecturer")) {
            try {
                System.out.println("lecturer entering class");
                //
                numOfLecturers.acquire();
                //
                this.isLecturer = true;

                //
            }catch (InterruptedException e) {
                e.printStackTrace();
            }finally {
                System.out.println("finished lecture");
                this.isLecturer = true;
                numOfLecturers.release();

            }
        }
        
    }
    public boolean enter() {
        if(isLecturer && inSession) {
            System.out.println("Sorry Lecturer in class " + this.title + " You can enter");
            return this.inLecture = false;
        }else {
            System.out.println("Successfully enter classroom " + this.title);
            return this.inLecture = true;
        }

    }
    //lecturer startLecture
    public void startLecture () {
        this.inSession = true;
        this.isLecturer = true;
    }
    public boolean leave (String person) {
        if (person.equals("visitor")){
            System.out.println("You have left the class " + this.title);
            this.isSeated = false;
            return this.inLecture = false;
        }
        // lecturer leaves
        else {
            System.out.println(" class " + this.title + " Over" );
            this.inLecture = false;
            return this.inSession = false;
        }

    }
// invoke by  student
    public boolean leave() {
        if (inSession){
            System.out.println("Sorry you can't leave the lecture " + this.title + " in session");
            return this.inLecture = true;
        }else{
            System.out.println("You have left the class " + this.title);
            this.isSeated = false;
            return this.inLecture = false;
        }

    }

    public boolean sitDown() {
        return isSeated = true;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public boolean isInSession() {
        return inSession;
    }

    public void setInSession(boolean inSession) {
        this.inSession = inSession;
    }

    public boolean isLecturer() {
        return isLecturer;
    }

    public void setLecturer(boolean lecturer) {
        isLecturer = lecturer;
    }
}
