package models;

public class Lecturer {

}
