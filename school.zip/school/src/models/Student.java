package models;

public class Student extends Classroom {
    @Override
    public boolean enter() {
        return super.enter();
    }

    @Override
    public boolean sitDown() {
        return super.sitDown();
    }

    @Override
    public boolean leave() {
        return super.leave();
    }
}
